function navigateTo(page) {
    window.location.href = page;
  }